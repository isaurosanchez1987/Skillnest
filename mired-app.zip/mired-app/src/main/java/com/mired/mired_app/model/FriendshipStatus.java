package com.mired.mired_app.model;

public enum FriendshipStatus {
    PENDING, ACCEPTED, REJECTED
}
